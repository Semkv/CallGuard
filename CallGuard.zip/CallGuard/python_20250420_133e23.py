from fastapi import FastAPI, HTTPException  
from pydantic import BaseModel  

app = FastAPI()  

class CallRequest(BaseModel):  
    phone_number: str  

@app.post("/check_call")  
async def check_call(request: CallRequest):  
    # Базовая логика проверки  
    return {"status": "allowed"}  