package com.callguard  

import android.telecom.Call  
import android.telecom.CallScreeningService  

class CallService : CallScreeningService() {  
    override fun onScreenCall(call: Call.Details) {  
        // Базовая логика блокировки  
    }  
}  